// Copyright (c) 2010-2011 Turbulenz Limited
;

;

/*global $*/
//
// HTML Controls
//
var HTMLControls = (function () {
    function HTMLControls() {
        this.version = 1;
    }
    HTMLControls.prototype.setSelectedRadio = function (groupName, index) {
        var controlGroup = this.radioControls[groupName];
        var control;
        if (controlGroup) {
            control = controlGroup.controls[index];
            if (control) {
                // Only set if the control at that index exists
                controlGroup.selected = index;
                this.updateRadio(control.id, true);
            }
        }
    };

    HTMLControls.prototype.addRadioControl = function (radioControlOptions) {
        var radioControls = this.radioControls;
        var groupName = radioControlOptions.groupName;
        var radioIndex = radioControlOptions.radioIndex;
        var radioID = radioControlOptions.id;

        //var value = radioControlOptions.value;
        var fn = radioControlOptions.fn;
        var isDefault = radioControlOptions.isDefault;

        if (groupName === undefined || groupName === null || radioIndex < 0 || radioID === undefined || radioID === null || fn === undefined || fn === null) {
            return;
        }

        var controlGroup = radioControls[groupName];
        if (!controlGroup) {
            radioControls[groupName] = {};
            controlGroup = radioControls[groupName];
            controlGroup.controls = [];
            controlGroup.selected = 0;
        }
        controlGroup.controls[radioIndex] = radioControlOptions;
        if (isDefault) {
            controlGroup.selected = radioIndex;
        }

        this.updateRadio(radioID, isDefault);
    };

    HTMLControls.prototype.addCheckboxControl = function (checkboxControlOptions) {
        var checkboxControls = this.checkboxControls;
        var id = checkboxControlOptions.id;
        var value = checkboxControlOptions.value;
        checkboxControls[value] = checkboxControlOptions;
        this.updateCheckbox(id, checkboxControlOptions.isSelected);
    };

    HTMLControls.prototype.addButtonControl = function (buttonControlOptions) {
        var buttonControls = this.buttonControls;
        var id = buttonControlOptions.id;
        buttonControls[id] = buttonControlOptions;
    };

    HTMLControls.prototype.addSliderControl = function (sliderControlOptions) {
        var sliderControls = this.sliderControls;
        sliderControls[sliderControlOptions.id] = sliderControlOptions;
    };

    HTMLControls.prototype.getSliderValue = function (id) {
        var value = window.$('#' + id).value;
        if (value) {
            return parseInt(value, 10);
        }
        return undefined;
    };

    HTMLControls.prototype.getHandler = function () {
        var radioControls = this.radioControls;
        var checkboxControls = this.checkboxControls;
        var buttonControls = this.buttonControls;
        return function (e) {
            var target;
            if (!e) {
                //IE
                e = window.event;
            }
            if (e.target) {
                //W3C
                target = e.target;
            } else if (e.srcElement) {
                //IE
                target = e.srcElement;
            }

            if (target.nodeType === 3) {
                // Safari fix
                target = target.parentNode;
            }

            var id = target.id;
            var control;
            switch (target.type) {
                case "radio":
                    for (var g in radioControls) {
                        if (radioControls.hasOwnProperty(g)) {
                            var index = 0;
                            var controls = radioControls[g].controls;
                            var length = controls.length;
                            while (index < length) {
                                control = controls[index];
                                if (control.id === id) {
                                    control.fn();
                                    return;
                                }
                                index += 1;
                            }
                        }
                    }
                    break;
                case "checkbox":
                    for (var c in checkboxControls) {
                        if (checkboxControls.hasOwnProperty(c)) {
                            control = checkboxControls[c];
                            if (control.id === id) {
                                var result = control.fn();

                                if (result !== undefined) {
                                    (document.getElementById(control.id)).checked = !!result;
                                }

                                return;
                            }
                        }
                    }
                    break;
                case "button":
                    for (var b in buttonControls) {
                        if (buttonControls.hasOwnProperty(b)) {
                            control = buttonControls[b];
                            if (b === id) {
                                control.fn();
                                return;
                            }
                        }
                    }
                    break;
                default:
            }
        };
    };

    HTMLControls.prototype.register = function () {
        var radioControls = this.radioControls;
        var checkboxControls = this.checkboxControls;
        var buttonControls = this.buttonControls;
        var sliderControls = this.sliderControls;
        var control, element, id;
        for (var g in radioControls) {
            if (radioControls.hasOwnProperty(g)) {
                var defaultIndex = radioControls[g].selected;
                var controls = radioControls[g].controls;
                var length = controls.length;
                for (var i = 0; i < length; i += 1) {
                    control = controls[i];
                    id = control.id;
                    element = document.getElementById(id);
                    if (element) {
                        element.value = control.value;
                        element.name = control.groupName;
                        element.onclick = this.getHandler();
                        element.checked = (defaultIndex === control.radioIndex) ? "checked" : "";
                    }
                }
            }
        }

        for (var c in checkboxControls) {
            if (checkboxControls.hasOwnProperty(c)) {
                control = checkboxControls[c];
                id = control.id;
                element = document.getElementById(id);
                if (element) {
                    element.value = control.value;
                    element.onclick = this.getHandler();
                    element.checked = control.isSelected ? "checked" : "";
                }
            }
        }

        for (var b in buttonControls) {
            if (buttonControls.hasOwnProperty(b)) {
                control = buttonControls[b];
                id = b;
                element = document.getElementById(id);
                if (element) {
                    element.value = control.value;
                    element.onclick = this.getHandler();
                }
            }
        }

        function createSliderCallback(id) {
            return function (event, ui) {
                var input = window.$("#" + id + "input");
                input.val(ui.value);
                input.change();
            };
        }

        function createInputCallback(control, id) {
            return function () {
                var value = parseFloat((this).value);

                if (!window.$) {
                    return;
                }
                var slider = window.$("#" + id);
                var input = window.$("#" + id + "input");
                if (!slider || !input) {
                    return;
                }
                var sliderVal = (slider.slider("value"));
                if (value === undefined || isNaN(value) || sliderVal === undefined || isNaN(sliderVal) || (sliderVal === value)) {
                    // Don't update if not changed
                    return;
                }

                var min = slider.slider("option", "min");
                var max = slider.slider("option", "max");
                if (value < min) {
                    value = min;
                } else if (value > max) {
                    value = max;
                }

                input.val(value);

                control.value = value;
                control.fn();
            };
        }

        for (var s in sliderControls) {
            if (sliderControls.hasOwnProperty(s)) {
                control = sliderControls[s];
                id = control.id;

                if (!window.$) {
                    return;
                }
                var slider = window.$("#" + id);
                var input = window.$("#" + id + "input");
                if (!slider || !input) {
                    return;
                }

                // Use jquery for sliders
                slider.slider({
                    value: control.value,
                    min: control.min,
                    max: control.max,
                    step: control.step,
                    slide: createSliderCallback(id)
                });

                input.val(slider.slider("value"));
                input.change(createInputCallback(control, id));
            }
        }

        this.registered = true;
    };

    HTMLControls.prototype.updateRadio = function (elementID, isSelected) {
        if (!this.registered) {
            return;
        }

        var element = (document.getElementById(elementID));
        if (element) {
            element.checked = !!isSelected;
        }
    };

    HTMLControls.prototype.updateCheckbox = function (elementID, isSelected) {
        if (!this.registered) {
            return;
        }

        var element = (document.getElementById(elementID));
        if (element) {
            element.checked = !!isSelected;
        }
    };

    HTMLControls.prototype.updateSlider = function (elementID, value) {
        if (!this.registered) {
            return;
        }

        if (window.$) {
            var element = window.$("#" + elementID);
            if (element) {
                element.slider("option", "value", value);
            }
        }
    };

    HTMLControls.create = // Constructor function
    function () {
        var c = new HTMLControls();
        c.radioControls = {};
        c.checkboxControls = {};
        c.buttonControls = {};
        c.sliderControls = {};
        c.registered = false;
        return c;
    };
    return HTMLControls;
})();
